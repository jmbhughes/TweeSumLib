package DUC::Document;
