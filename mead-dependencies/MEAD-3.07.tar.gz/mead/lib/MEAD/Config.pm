package MEAD::Config;

require Exporter;

@ISA = qw(Exporter);
@EXPORT = qw(write_meadconfig

	     read_meadrc);

use strict;

use MEAD::MEAD;

#
# TODO: AJW 9/17
# read_meadconfig
# write_meadrc
#

sub write_meadconfig {

    my %opts = @_;

    # Get the particular options.
    my $target = $opts{'target'};
    my $lang = $opts{'lang'};
    my $cluster_dir = $opts{'cluster_dir'};
    my $docsent_dir = $opts{'docsent_dir'};

    my $feature_dir = $opts{'feature_dir'};
    my %features;
    if ( $opts{'features'} ) {
	%features = %{ $opts{'features'} };
    }

    my $system = $opts{'system'};
    my $run = $opts{'run'};
    
    my $classifier = $opts{'classifier'};
    my $reranker = $opts{'reranker'};

    my $compression_basis = $opts{'compression_basis'};
    my $compression_absolute = $opts{'compression_absolute'};
    my $compression_percent = $opts{'compression_percent'};

    my $output = $opts{'OUTPUT'} || \*STDOUT;
    unless (ref $output) {
	open TEMP, ">$output" or
	    die "Unable to open '$output' for writing meadconfig.\n";
	$output = \*TEMP;
    }

    # Now write the XML.
    my $writer = new XML::Writer(DATA_MODE => 1, OUTPUT => $output);
    
    $writer->xmlDecl();
    
    $writer->startTag("MEAD-CONFIG", 
		      "LANG" => $lang, 
		      "TARGET" => $target,
		      "CLUSTER-PATH" => $cluster_dir,
		      "DOC-DIRECTORY" => $docsent_dir);
    
    $writer->startTag("FEATURE-SET", 
		      "BASE-DIRECTORY" => $feature_dir);
    
    foreach my $feature_name (keys %features) {
	$writer->emptyTag("FEATURE", 
			  "NAME" => $feature_name, 
			  "SCRIPT" => $features{$feature_name});
    }
    
    $writer->endTag();
    
    $writer->emptyTag("CLASSIFIER", 
		      "COMMAND-LINE" => $classifier,
		      "SYSTEM" => $system,
		      "RUN" => $run);
    
    $writer->emptyTag("RERANKER", 
		      "COMMAND-LINE" => $reranker);
    
    if ($compression_absolute) {
	$writer->emptyTag("COMPRESSION",
			  "BASIS" => $compression_basis,
			  "ABSOLUTE" => $compression_absolute);
    } else {
	$writer->emptyTag("COMPRESSION",
			  "BASIS" => $compression_basis, 
			  "PERCENT" => $compression_percent);
    }
    
    $writer->endTag();
    
    $writer->end();
    
}

sub read_meadrc {

    my $rcfile = shift;

    my %rc = ();
    $rc{'features'} = {};

    unless (open RC, $rcfile) {
	Debug("Unable to open $rcfile", 2, "MEAD::Config::read_meadrc");
	return undef;
    }

    my $l;
    while ($l = <RC>) {

	chomp $l;

	next if $l =~ /^#/;
	next if $l =~ /^\s*$/;

	# this is for features only.
	if ($l =~ /^\s*feature\s+(\S+)\s+(.+)$/) {

	    my $featuresref = $rc{'features'};
	    $$featuresref{$1} = $2;

	# this is the general case.
	} elsif ($l =~ /^\s*(\w+)\s+(\S.*)$/) {
	    $rc{$1} = $2;
	}

    }

    return %rc;
}




